<script setup lang='ts'>
</script>
<template>
    <div>
        <slot></slot>
    </div>
</template>
<style>
    slot {
        width: 159px;
        height: 100px;
    }
</style>
<script>
import SettingsMenu from '../components/layouts/SettingsMenu.vue'

export default {
  components: {
    SettingsMenu
  }
}
</script>
<template>
  <main>
      <SettingsMenu></SettingsMenu>
  </main>
</template>
<style>
</style>
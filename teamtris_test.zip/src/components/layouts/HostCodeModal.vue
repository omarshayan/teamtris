<script setup lang='ts'>
    import Button from '@/components/elements/Button.vue'
</script>
<template>
    <slot></slot>
    <Button></Button>
</template>
<style></style>

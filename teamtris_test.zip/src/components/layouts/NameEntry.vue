<script setup lang='ts'>
    import NameEntryModal from '@/components/elements/NameEntryModal.vue';
</script>
<template>
    <NameEntryModal>
    </NameEntryModal>
</template>
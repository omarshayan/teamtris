function Message(metadata, content){
    this.sender = "server"
    this.metadata = metadata
    this.content = content
    
}

export default Message
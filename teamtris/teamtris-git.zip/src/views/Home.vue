<script>
import Menu from '../components/layouts/MainMenu.vue'

export default {
  components: {
    Menu,
}
}
</script>
<template>
<main>
      <Menu></Menu>
  </main>
</template>
<style>
@import '@/assets/css/menu.css';
</style>
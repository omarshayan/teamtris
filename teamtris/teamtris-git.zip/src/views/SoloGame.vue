<script setup lang='ts'>
  import Game from '@/components/layouts/Game.vue'
</script>
<template>
  <Game :num-lines="40"></Game>
</template>
<style scoped>
@import '@/assets/css/game.css';
</style>
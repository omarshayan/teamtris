<template>
        <img src='../../assets/new-game-preview-half.svg'>
</template>
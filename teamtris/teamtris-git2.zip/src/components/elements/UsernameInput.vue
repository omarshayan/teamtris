<script setup lang='ts'>
    import Input from '@/components/elements/Input.vue'


</script>
<template>
    <Input></Input>
</template>